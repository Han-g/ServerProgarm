#include <windows.h>
#include <tchar.h>
#include "resource.h"

HINSTANCE g_hInst;
LPCTSTR lpszClass = L"Test Client";
LPCTSTR lpszWindowName = L"Test Client";

HWND hWnd;

struct Object {
	int x, y;
};

Object player[1];
int Num_Objects = 1;

void RenderBackground(PAINTSTRUCT ps, HDC hdc) {
	/*static HBITMAP hBit;
	hBit = (HBITMAP)LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP1));
	if (hBit == NULL) {
		// ���� ó��
		MessageBox(NULL, L"�̹����� �ҷ��� �� �����ϴ�.", L"����", MB_OK | MB_ICONERROR);
		return;
	}

	HDC memdc = CreateCompatibleDC(hdc);
	SelectObject(memdc, hBit);

	BitBlt(hdc, 0, 0, 640, 640, memdc, 0, 0, SRCCOPY);
	DeleteDC(memdc);*/
	HBRUSH hBrush = CreateSolidBrush(RGB(100, 100, 100));
	if (hBrush == NULL) {
		MessageBox(NULL, L"�귯�ø� ������ �� �����ϴ�.", L"����", MB_OK | MB_ICONERROR);
		return;
	}

	RECT rect;
	for (int i = 0; i < 8; i += 2) {
		for (int j = 0; j < 8; j += 2) {
			SetRect(&rect, 80 * i, 80 * j, 80 * (i + 1), 80 * (j + 1));
			FillRect(hdc, &rect, hBrush);
		}
	}
	for (int i = 1; i < 8; i += 2) {
		for (int j = 1; j < 8; j += 2) {
			SetRect(&rect, 80 * i, 80 * j, 80 * (i + 1), 80 * (j + 1));
			FillRect(hdc, &rect, hBrush);
		}
	}

	DeleteObject(hBrush);
}

void RenderObject(PAINTSTRUCT ps, HDC hdc) {
	HBITMAP hBit;

	for (int i = 0; i < Num_Objects; ++i) {
		hBit = (HBITMAP)LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));
		if (hBit == NULL) {
			// ���� ó��
			MessageBox(NULL, L"�̹����� �ҷ��� �� �����ϴ�.", L"����", MB_OK | MB_ICONERROR);
			return;
		}

		HDC memdc = CreateCompatibleDC(hdc);
		SelectObject(memdc, hBit);

		StretchBlt(hdc, player[0].x * 80, player[0].y * 80, 80, 80, 
			memdc, 0, 0, 20, 20, SRCCOPY);
		DeleteDC(memdc);
	}
}

void Move(int* x, int* y, WPARAM wParam) {
	switch (wParam)
	{
	case 37:	//left
		if(player[0].x > 0) player[0].x -= 1;
		break;
	case 38:	//up
		if (player[0].y > 0) player[0].y -= 1;
		break;
	case 39:	//right
		if (player[0].x < 7) player[0].x += 1;
		break;
	case 40:	//down
		if (player[0].y < 7) player[0].y += 1;
		break;

	default:
		break;
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
					LPSTR lpszCmdParam, int nCmdShow)
{
	MSG Message;
	WNDCLASSEX WndClass;

	g_hInst = hInstance;

	WndClass.cbSize = sizeof(WndClass);
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = (WNDPROC)WndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInstance;
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.lpszMenuName = NULL;
	WndClass.lpszClassName = lpszClass;
	WndClass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	RegisterClassEx(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszWindowName, WS_OVERLAPPEDWINDOW, 0, 0, 655, 675, NULL,
		(HMENU)NULL, hInstance, NULL);

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	player[0].x = 0; player[0].y = 0;

	while (GetMessage(&Message, 0, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}

	return Message.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hDC = GetDC(hWnd);
	HBITMAP hBitmap;
	//--- �޽��� ó���ϱ�

	switch (uMsg) {
	case WM_CREATE:
		break;
	case WM_KEYDOWN:
		Move(&player[0].x, &player[0].y, wParam);
		InvalidateRect(hWnd, NULL, true);
		break;
	case WM_PAINT:
		hDC = BeginPaint(hWnd, &ps);
		RenderBackground(ps, hDC);
		RenderObject(ps, hDC);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
	//--- ���� �� �޽��� ���� ������ �޽����� OS��
}